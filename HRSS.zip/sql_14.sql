create database aws_data;
use AWS_data;

show tables;
select * from user_details;

select * from houses;

insert into houses(sno,address,city,oname,phno,pincode,price,type) values (1,'Chhota Govindpur','Jamshedpur','Ashu','9113104593','831004','2500','1_BHK');

insert into houses(sno,address,city,oname,phno,pincode,price,type) values (2,'Anywhere in Bengaluru','Bengaluru','Ashu','9113104593','721100','5000','1_BHK');
insert into houses(sno,address,city,oname,phno,pincode,price,type) values (3,'Anywhere in mumbai','Mumbai','Raunak','8754697812','412005','3500','1_BHK');
insert into houses(sno,address,city,oname,phno,pincode,price,type) values (6,'Nowhere in Bengaluru','Bengaluru','Dhanush','7845614520','721102','6500','1_BHK');

delete from houses
where sno=4; 