package com.torryharris.ItemList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.ApplicationContext;

//import com.torryharris.DemoSpringBoot.dao.UserRepository;
import com.torryharris.ItemList.repository.userRepo;

@SpringBootApplication
public class FormvalidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormvalidationApplication.class, args);
		
		
	}

}
